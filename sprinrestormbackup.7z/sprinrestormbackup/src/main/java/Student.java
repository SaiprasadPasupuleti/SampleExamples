/**
 * Created by DT214019 on 11/15/2018.
 */
public class Student {

  private int sid;
  private String sname;
  private String rno;

  public int getSid() {
    return sid;
  }

  public void setSid(int sid) {
    this.sid = sid;
  }

  public String getSname() {
    return sname;
  }

  public void setSname(String sname) {
    this.sname = sname;
  }

  public String getRno() {
    return rno;
  }

  public void setRno(String rno) {
    this.rno = rno;
  }

  public Student() {
  }
}
