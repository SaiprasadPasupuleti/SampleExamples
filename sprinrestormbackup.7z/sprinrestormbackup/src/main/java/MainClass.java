import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Created by DT214019 on 11/15/2018.
 */
public class MainClass {

  public static void main(String[] args) {
    ApplicationContext context= new ClassPathXmlApplicationContext("spring.xml");
    Person s= (Person) context.getBean("person");
    System.out.println(s.getPadd());
    System.out.println(s.getPid());
    System.out.println(s.getPname());
    System.out.println(s.getStudent().getSid());
   // System.out.println();
  }
}
