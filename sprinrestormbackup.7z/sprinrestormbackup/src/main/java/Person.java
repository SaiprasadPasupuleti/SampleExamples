import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by DT214019 on 11/15/2018.
 */
public class Person {

  private String pid;
  private String pname;
  private String padd;
  private Student student;

  public Student getStudent() {
    return student;
  }

  public void setStudent(Student student) {
    this.student = student;
  }


@Autowired
  public Person(String padd, String pid, String pname,   Student student) {
    this.padd = padd;
    this.pid = pid;
    this.pname = pname;
    this.student = student;
  }

  public String getPid() {
    return pid;
  }

  public void setPid(String pid) {
    this.pid = pid;
  }

  public String getPname() {
    return pname;
  }

  public void setPname(String pname) {
    this.pname = pname;
  }

  public String getPadd() {
    return padd;
  }

  public void setPadd(String padd) {
    this.padd = padd;
  }
}
