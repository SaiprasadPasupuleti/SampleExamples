package edu.springrestorm.controller;

import edu.springrestorm.model.Employee;
import edu.springrestorm.repositoryimpl.CustomerDAOImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Created by DT214019 on 11/16/2018.
 */
@RestController
public class CustomerResource {

  @Autowired
  CustomerDAOImpl customerDAO;

  @RequestMapping(name = "/addEmployee", method = RequestMethod.POST, produces = "application/json",consumes = "application/json")
  public void addCustomer(@RequestBody Employee employee) {
    System.out.println("Inservice");
        customerDAO.addCustomer(employee);
  }

  @RequestMapping(name = "/getEmployee", method = RequestMethod.GET, produces = "application/json")
  public List<Employee> getEmployee() {
    System.out.println("Inservice 2222");
   return customerDAO.getEmployee();
  }
}
