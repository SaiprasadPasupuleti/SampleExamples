package edu.springrestorm.repositoryimpl;

import edu.springrestorm.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by DT214019 on 11/16/2018.
 */
@Repository
@Transactional
public class CustomerDAOImpl{

  @Autowired
HibernateTemplate template;

  public HibernateTemplate getTemplate() {
    return template;
  }

  public void setTemplate(HibernateTemplate template) {
    this.template = template;
  }

  public void addCustomer(Employee employee) {
    System.out.println("InDao");
    getTemplate().save(employee);
  }

  public List<Employee> getEmployee() {
    return getTemplate().loadAll(Employee.class);
  }
}
