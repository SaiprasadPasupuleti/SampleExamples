package edu.springrestorm.model;

/**
 * Created by DT214019 on 11/16/2018.
 */
public class TestClass {

  public void m1(byte b,byte c){
    byte d=(byte)((byte) b+(byte)c);//compile time error will give
  }
  public static void main(String[] args) {

  }
}
