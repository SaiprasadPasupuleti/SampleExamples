package edu.springrest.orm.controller;

import edu.springrest.orm.component.Customer;
import edu.springrest.orm.services.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController//@Controller and @Responsebody
public class CustomerResource {

    @Autowired(required = true)
    private CustomerService customerService;

    @RequestMapping(value = "/employee", method = RequestMethod.GET, produces = "application/json")
    public List<Customer> getCustomer() {
        System.out.println("inservice");
        return customerService.getEmployee();
    }

    @RequestMapping(value = "/addCustomer" , method = RequestMethod.POST,consumes = "application/json",produces = "application/json")
    public void addCustomer(@RequestBody Customer customer){
     customerService.addCustomer(customer);
    }

}
