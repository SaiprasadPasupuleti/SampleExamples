package edu.springrest.orm.services;

import edu.springrest.orm.component.Customer;
import edu.springrest.orm.repositories.CustomerDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service

public class CustomerService {

    @Autowired
    private CustomerDAO customerDAO;

    public List<Customer> getEmployee() {
        return customerDAO.getEmployee();
    }

    public void addCustomer(Customer customer) {
        customerDAO.addCustomer(customer);
    }
}
