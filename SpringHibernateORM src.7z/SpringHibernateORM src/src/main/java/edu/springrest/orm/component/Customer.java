package edu.springrest.orm.component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;

@Entity
@Table(name = "customer")
@Component
public class Customer implements Serializable {
    @Id
    @Column(name = "custId")
    int custId;
    @Column(name = "custName")
    String custName;
    @Column(name = "custAdd")
    String custAddr;

    public Customer() {
    }

    public int getCustId() {
        return custId;
    }

    public void setCustId(int custId) {
        this.custId = custId;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public String getCustAddr() {
        return custAddr;
    }

    public void setCustAddr(String custAddr) {
        this.custAddr = custAddr;
    }

    public Customer(int custId, String custName, String custAddr) {
        this.custId = custId;
        this.custName = custName;
        this.custAddr = custAddr;
    }
}
