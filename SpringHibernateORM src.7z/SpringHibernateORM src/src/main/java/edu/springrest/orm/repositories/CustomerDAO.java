package edu.springrest.orm.repositories;

import edu.springrest.orm.component.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class CustomerDAO {

    @Autowired
    private HibernateTemplate template;


    public HibernateTemplate getTemplate() {
        return template;
    }

    public void setTemplate(HibernateTemplate hibernateTemplate) {
        this.template = hibernateTemplate;
    }

    public List<Customer> getEmployee() {
        List<Customer> customerList = getTemplate().loadAll(Customer.class);
        return customerList;
    }

    public void addCustomer(Customer customer) {
        getTemplate().save(customer);
    }
}
