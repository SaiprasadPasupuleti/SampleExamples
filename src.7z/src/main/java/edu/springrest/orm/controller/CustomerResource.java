package edu.springrest.orm.controller;

import edu.springrest.orm.component.EmployeeModel;
import edu.springrest.orm.repositories.CustomerDAO;
import edu.springrest.orm.services.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
@RestController
public class CustomerResource {

    @Autowired
    CustomerService customerService;
    @RequestMapping(value = "/employee", method = RequestMethod.GET,produces = "application/json")
    public List<EmployeeModel> getCustomer(){
        System.out.println("inservice");
        return customerService.getEmployee();
    }


}
