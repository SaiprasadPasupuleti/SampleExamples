package edu.springrest.orm.repositories;

import edu.springrest.orm.component.EmployeeModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;

import java.util.List;

public class CustomerDAO {

    @Autowired
    HibernateTemplate template;


    public HibernateTemplate getHibernateTemplate() {
        return template;
    }

    public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
        this.template = hibernateTemplate;
    }

    public List<EmployeeModel> getEmployee(){
        List<EmployeeModel> employeeModelList=getHibernateTemplate().loadAll(EmployeeModel.class);
        return employeeModelList;
    }
}
