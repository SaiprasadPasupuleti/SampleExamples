package edu.springrest.orm.services;

import edu.springrest.orm.component.EmployeeModel;
import edu.springrest.orm.repositories.CustomerDAO;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class CustomerService {

    @Autowired
    CustomerDAO customerDAO;
    public List<EmployeeModel> getEmployee(){
        return customerDAO.getEmployee();
    }
}
